library(tidyverse)
library(shiny)
library(leaflet)
library(DT)

met_shows_city_stats <- readRDS(file="~/Projects/Metallica/Shiny/data/met_shows_city_stats_20241215.Rda")
met_shows <- readRDS(file="~/Projects/Metallica/Shiny/data/met_shows_20241215.Rda")

server <- function(input, output) {
  output$Table <- DT::renderDataTable({
    data <- met_shows
    if (input$continent != "All") {
      data <- data[data$continent == input$continent,]
    }
    if (input$country != "All") {
      data <- data[data$country == input$country,]
    }
    if (input$state != "All") {
      data <- data[data$state == input$state,]
    }
    if (input$city != "All") {
      data <- data[data$city == input$city,]
    }
    DT::datatable(data)
    })
  
  output$Map <- leaflet::renderLeaflet({
    data_map <- leaflet::leaflet(met_shows_city_stats) %>%
      leaflet::addTiles() %>%
      leaflet::addCircleMarkers(
        lng=~long,
        lat=~lat,
        layerId = ~city_num,
        radius = ~sqrt(n_shows)*2,
        color = "purple",
        stroke = FALSE,
        fillOpacity = 0.5,
        popup = paste(paste('<b>City:</b>',met_shows_city_stats$city),
                      paste('<b>Nb of Shows:</b>',met_shows_city_stats$n_shows),
                      paste('<b>First Show:</b>',met_shows_city_stats$min_date),
                      paste('<b>Last Show:</b>',met_shows_city_stats$max_date),
                      sep = '<br/>')) %>%
      addMiniMap(width = 150, height = 150)
    data_map
  })
  
}

ui <- fluidPage( titlePanel(h3("Metallica Shows per City")),
                 a(href="https://www.metallica.com/", "Using info from Metallica web page"),
  navbarPage("Metallica",
             tabPanel("Shows map",
                      leafletOutput("Map"),
                      hr(),
                      print("as of 20241215")
             ),
             tabPanel("Shows explorer",
                      fluidRow(
                        column(3,
                               selectInput("continent",
                                           "Continent:",
                                           c("All",
                                             unique(as.character(met_shows$continent))))
                        ),
                        column(3,
                               conditionalPanel("input.continent",
                                                selectInput("country",
                                                            "Country:",
                                                            c("All",
                                                              unique(as.character(met_shows$country)))))
                        ),
                        column(3,
                               selectInput("state",
                                           "State:",
                                           c("All",
                                             unique(as.character(met_shows$state))))
                        ),
                        column(3,
                               selectInput("city",
                                           "City:",
                                           c("All",
                                             unique(as.character(met_shows$city))))
                        )
                      ),
                      # Create a new row for the table.
                      DT::dataTableOutput("Table")
             )
  )
)

shinyApp(ui = ui, server = server)