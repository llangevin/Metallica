library(tidyverse)
library(shiny)
library(leaflet)
library(DT)

met_shows_city_stats <- readRDS("data/met_shows_city_stats_20241215.Rds")
#data <- met_shows_city_stats
data <- met_shows_city_stats %>%
  select(city_num, city, state, country, continent, n_shows) %>%
  arrange(city_num, city, state, country, continent)

# User interface ----
ui <- fluidPage(
  titlePanel(h3("Metallica Shows per City")),
  titlePanel(h6("as of 20241215")),
  leafletOutput("Map"),
  # Create a new Row in the UI for selectInputs
  fluidRow(
    column(3,
           selectInput("continent",
                       "Continent:",
                       c("All",
                         unique(as.character(met_shows_city_stats$continent))))
    ),
    column(3,
           conditionalPanel("input.continent",
                            selectInput("country",
                                        "Country:",
                                        c("All",
                                          unique(as.character(met_shows_city_stats$country)))))
    ),
    column(3,
           selectInput("state",
                       "State:",
                       c("All",
                         unique(as.character(met_shows_city_stats$state))))
    ),
    column(3,
           selectInput("city",
                       "City:",
                       c("All",
                         unique(as.character(met_shows_city_stats$city))))
    )
  ),
  # Create a new row for the table.
  DT::dataTableOutput("Table")
)

# Server logic ----
server <- function(input, output) {
  
  # Filter data based on selections
  output$Table <- DT::renderDataTable({
    #data <- met_shows_city_stats %>%
    #select(city_num, city, state, country, continent, n_shows) %>%
    #arrange(city_num, city, state, country, continent)
    if (input$continent != "All") {
      data <- data[data$continent == input$continent,]
    }
    if (input$country != "All") {
      data <- data[data$country == input$country,]
    }
    if (input$state != "All") {
      data <- data[data$state == input$state,]
    }
    if (input$city != "All") {
      data <- data[data$city == input$city,]
    }
    DT::datatable(data, selection = "single",options=list(stateSave = TRUE))})
  
  #  output$Table <- renderDataTable({
  #    DT::datatable(data, selection = "single",options=list(stateSave = TRUE))
  #  })
  
  output$Map <- leaflet::renderLeaflet({
    data_map <- leaflet::leaflet(met_shows_city_stats) %>%
      leaflet::addTiles() %>%
      leaflet::addCircleMarkers(
        lng=~long,
        lat=~lat,
        layerId = ~city_num,
        radius = ~sqrt(n_shows)*2,
        color = "purple",
        stroke = FALSE,
        fillOpacity = 0.5,
        popup = paste(paste('<b>City:</b>',met_shows_city_stats$city),
                      paste('<b>Nb of Shows:</b>',met_shows_city_stats$n_shows),
                      paste('<b>First Show:</b>',met_shows_city_stats$min_date),
                      paste('<b>Last Show:</b>',met_shows_city_stats$max_date),
                      sep = '<br/>')) %>%
      addMiniMap(width = 150, height = 150)
    data_map
  })
  
  shiny::observeEvent(input$Map_marker_click, {
    clickId <- input$Map_marker_click$id
    DT::dataTableProxy("Table") %>%
      DT::selectRows(which(data$city_num == clickId)) %>%
      DT::selectPage(which(input$Table_rows_all == clickId) %/% input$Table_state$length + 1)
  })
  
}

# Run app ----
shinyApp(ui, server)